#pragma once
#define ARRAY_LEN 256
#define MAX_BUFFER_LEN 256