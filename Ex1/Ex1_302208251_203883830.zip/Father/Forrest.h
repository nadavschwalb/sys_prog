 #pragma once
//Description - updates input array to next gen forrest array
//Parameters- pointer to char array, array size
//Returns - void
void forrest_next_gen(int forrest_size, char* old_forrest_array);
