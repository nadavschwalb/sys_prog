#pragma once
//Description - counts number of chars c in string str
//Parameters- char* to string, char c
//Returns - number of char c in str
int char_in_str(char* str, char c);