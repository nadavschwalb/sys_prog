#include <stdio.h>

void main()
{
	printf("Our IDs are: 302208251_203883830\n");
	return 0;
}